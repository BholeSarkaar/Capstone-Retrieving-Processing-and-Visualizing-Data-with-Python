gline = [ ['Month','umich.edu','indiana.edu','berkeley.edu','ucdavis.edu','uct.ac.za','ufp.pt','columbia.edu','mac.com','gmail.com','virginia.edu'],
['2005',57,12,12,11,14,10,13,12,10,9],
['2006',137,40,39,38,32,35,31,28,27,27]
];
